
Replace the three f90 files in the XClib directory of Quantum ESPRESSO for
the ones in this file. Run make all to compile it.
